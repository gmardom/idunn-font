# List of Character Variants of Iosevka

<!-- BEGIN Section-OT-Character-Variants -->
<!-- THIS SECTION IS AUTOMATICALLY GENERATED. DO NOT EDIT. -->

<table>
<tr>
<td rowspan="2"><code>cv01</code></td>
<td><img src="../images/cv-one-line.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-one-line.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-one-no-base.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-one-no-base.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-one-base.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-one-base.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-one-no-base-long-top-serif.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-one-no-base-long-top-serif.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-one-base-long-top-serif.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-one-base-long-top-serif.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-one-no-base-flat-top-serif.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-one-no-base-flat-top-serif.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-one-base-flat-top-serif.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-one-base-flat-top-serif.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-one-no-base-top-cut.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-one-no-base-top-cut.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-one-base-top-cut.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-one-base-top-cut.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="3"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td colspan="3"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv02</code></td>
<td><img src="../images/cv-two-straight-neck-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-two-straight-neck-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-two-straight-neck-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-two-straight-neck-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-two-curly-neck-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-two-curly-neck-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-two-curly-neck-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-two-curly-neck-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="8"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td colspan="8"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv03</code></td>
<td><img src="../images/cv-three-flat-top-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-three-flat-top-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-three-flat-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-three-flat-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-three-two-arcs.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-three-two-arcs.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv04</code></td>
<td><img src="../images/cv-four-closed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-four-closed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-four-closed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-four-closed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-four-closed-non-crossing-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-four-closed-non-crossing-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-four-closed-non-crossing-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-four-closed-non-crossing-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-four-semi-open-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-four-semi-open-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-four-semi-open-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-four-semi-open-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-four-semi-open-non-crossing-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-four-semi-open-non-crossing-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-four-semi-open-non-crossing-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-four-semi-open-non-crossing-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-four-open-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-four-open-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-four-open-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-four-open-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-four-open-non-crossing-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-four-open-non-crossing-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-four-open-non-crossing-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-four-open-non-crossing-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td rowspan="2"><code>cv05</code></td>
<td><img src="../images/cv-five-upright-arched-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-five-upright-arched-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-five-upright-arched-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-five-upright-arched-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-five-upright-flat-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-five-upright-flat-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-five-upright-flat-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-five-upright-flat-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-five-oblique-arched-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-five-oblique-arched-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-five-oblique-arched-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-five-oblique-arched-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-five-oblique-flat-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-five-oblique-flat-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-five-oblique-flat-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-five-oblique-flat-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="4"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td colspan="4"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv06</code></td>
<td><img src="../images/cv-six-closed-contour.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-six-closed-contour.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-six-open-contour.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-six-open-contour.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-six-straight-bar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-six-straight-bar.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv07</code></td>
<td><img src="../images/cv-seven-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-seven-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-seven-straight-serifless-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-seven-straight-serifless-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-seven-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-seven-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-seven-straight-serifed-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-seven-straight-serifed-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-seven-bend-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-seven-bend-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-seven-bend-serifless-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-seven-bend-serifless-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-seven-bend-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-seven-bend-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-seven-bend-serifed-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-seven-bend-serifed-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-seven-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-seven-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-seven-curly-serifless-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-seven-curly-serifless-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-seven-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-seven-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-seven-curly-serifed-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-seven-curly-serifed-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td rowspan="2"><code>cv08</code></td>
<td><img src="../images/cv-eight-crossing.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eight-crossing.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eight-two-circles.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eight-two-circles.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eight-crossing-asymmetric.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eight-crossing-asymmetric.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv09</code></td>
<td><img src="../images/cv-nine-closed-contour.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-nine-closed-contour.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-nine-open-contour.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-nine-open-contour.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-nine-straight-bar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-nine-straight-bar.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="10"><code>cv10</code></td>
<td><img src="../images/cv-zero-unslashed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-unslashed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-slashed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-slashed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-reverse-slashed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-reverse-slashed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-tall-slashed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-tall-slashed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-tall-reverse-slashed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-tall-reverse-slashed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-dotted.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-dotted.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-long-dotted.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-long-dotted.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-slashed-split.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-slashed-split.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-reverse-slashed-split.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-reverse-slashed-split.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-broken-slash.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-broken-slash.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-broken-reverse-slash.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-broken-reverse-slash.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-broken-vertical-bar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-broken-vertical-bar.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-zero-slashed-cutout.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-slashed-cutout.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-reverse-slashed-cutout.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-reverse-slashed-cutout.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-tall-slashed-cutout.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-tall-slashed-cutout.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-tall-reverse-slashed-cutout.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-tall-reverse-slashed-cutout.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-vertical-bar-cutout.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-vertical-bar-cutout.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-top-right-cutout.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-top-right-cutout.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-oval-unslashed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-oval-unslashed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-oval-slashed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-oval-slashed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-oval-reverse-slashed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-oval-reverse-slashed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-oval-tall-slashed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-oval-tall-slashed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-oval-tall-reverse-slashed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-oval-tall-reverse-slashed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-oval-dotted.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-oval-dotted.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td>21</td>
<td>22</td>
<td>23</td>
<td>24</td>
</tr>
<tr>
<td><img src="../images/cv-zero-oval-long-dotted.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-oval-long-dotted.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-oval-slashed-split.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-oval-slashed-split.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-oval-reverse-slashed-split.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-oval-reverse-slashed-split.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-oval-broken-slash.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-oval-broken-slash.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-oval-broken-reverse-slash.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-oval-broken-reverse-slash.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-oval-broken-vertical-bar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-oval-broken-vertical-bar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-oval-slashed-cutout.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-oval-slashed-cutout.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-oval-reverse-slashed-cutout.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-oval-reverse-slashed-cutout.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-oval-tall-slashed-cutout.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-oval-tall-slashed-cutout.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-oval-tall-reverse-slashed-cutout.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-oval-tall-reverse-slashed-cutout.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-oval-vertical-bar-cutout.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-oval-vertical-bar-cutout.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-oval-top-right-cutout.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-oval-top-right-cutout.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>25</td>
<td>26</td>
<td>27</td>
<td>28</td>
<td>29</td>
<td>30</td>
<td>31</td>
<td>32</td>
<td>33</td>
<td>34</td>
<td>35</td>
<td>36</td>
</tr>
<tr>
<td><img src="../images/cv-zero-diamond-unslashed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-diamond-unslashed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-diamond-slashed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-diamond-slashed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-diamond-reverse-slashed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-diamond-reverse-slashed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-diamond-tall-slashed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-diamond-tall-slashed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-diamond-tall-reverse-slashed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-diamond-tall-reverse-slashed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-diamond-dotted.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-diamond-dotted.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-diamond-long-dotted.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-diamond-long-dotted.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-diamond-slashed-split.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-diamond-slashed-split.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-diamond-reverse-slashed-split.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-diamond-reverse-slashed-split.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-diamond-broken-slash.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-diamond-broken-slash.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-diamond-broken-reverse-slash.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-diamond-broken-reverse-slash.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-diamond-broken-vertical-bar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-diamond-broken-vertical-bar.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>37</td>
<td>38</td>
<td>39</td>
<td>40</td>
<td>41</td>
<td>42</td>
<td>43</td>
<td>44</td>
<td>45</td>
<td>46</td>
<td>47</td>
<td>48</td>
</tr>
<tr>
<td><img src="../images/cv-zero-diamond-slashed-cutout.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-diamond-slashed-cutout.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-diamond-reverse-slashed-cutout.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-diamond-reverse-slashed-cutout.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-diamond-tall-slashed-cutout.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-diamond-tall-slashed-cutout.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-diamond-tall-reverse-slashed-cutout.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-diamond-tall-reverse-slashed-cutout.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-diamond-vertical-bar-cutout.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-diamond-vertical-bar-cutout.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-zero-diamond-top-right-cutout.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-zero-diamond-top-right-cutout.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td>49</td>
<td>50</td>
<td>51</td>
<td>52</td>
<td>53</td>
<td>54</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv11</code></td>
<td><img src="../images/cv-capital-a-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-a-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-a-straight-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-a-straight-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-a-straight-base-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-a-straight-base-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-a-straight-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-a-straight-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-a-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-a-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-a-curly-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-a-curly-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-a-curly-base-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-a-curly-base-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-a-curly-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-a-curly-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-a-round-top-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-a-round-top-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-a-round-top-base-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-a-round-top-base-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="2"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td colspan="2"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv12</code></td>
<td><img src="../images/cv-capital-b-standard-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-b-standard-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-b-standard-unilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-b-standard-unilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-b-standard-bilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-b-standard-bilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-b-standard-interrupted-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-b-standard-interrupted-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-b-standard-interrupted-unilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-b-standard-interrupted-unilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-b-standard-interrupted-bilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-b-standard-interrupted-bilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-b-more-asymmetric-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-b-more-asymmetric-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-b-more-asymmetric-unilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-b-more-asymmetric-unilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-b-more-asymmetric-bilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-b-more-asymmetric-bilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-b-more-asymmetric-interrupted-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-b-more-asymmetric-interrupted-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-b-more-asymmetric-interrupted-unilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-b-more-asymmetric-interrupted-unilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-b-more-asymmetric-interrupted-bilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-b-more-asymmetric-interrupted-bilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td rowspan="2"><code>cv13</code></td>
<td><img src="../images/cv-capital-c-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-c-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-c-unilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-c-unilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-c-bilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-c-bilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-c-unilateral-inward-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-c-unilateral-inward-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-c-bilateral-inward-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-c-bilateral-inward-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="7"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td colspan="7"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv14</code></td>
<td><img src="../images/cv-capital-d-standard-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-d-standard-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-d-standard-unilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-d-standard-unilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-d-standard-bilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-d-standard-bilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-d-more-rounded-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-d-more-rounded-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-d-more-rounded-unilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-d-more-rounded-unilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-d-more-rounded-bilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-d-more-rounded-bilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv15</code></td>
<td><img src="../images/cv-capital-e-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-e-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-e-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-e-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-e-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-e-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-e-serifed-capped.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-e-serifed-capped.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="8"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td colspan="8"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv16</code></td>
<td><img src="../images/cv-capital-f-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-f-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-f-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-f-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-f-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-f-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-f-serifed-capped.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-f-serifed-capped.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="8"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td colspan="8"> </td>
</tr>
<tr>
<td rowspan="6"><code>cv17</code></td>
<td><img src="../images/cv-capital-g-toothed-serifless-hookless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothed-serifless-hookless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothed-serifless-hooked.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothed-serifless-hooked.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothed-serifless-capped.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothed-serifless-capped.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothed-serifed-hookless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothed-serifed-hookless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothed-serifed-hooked.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothed-serifed-hooked.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothed-serifed-capped.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothed-serifed-capped.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothed-inward-serifed-hookless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothed-inward-serifed-hookless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothed-inward-serifed-hooked.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothed-inward-serifed-hooked.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothed-inward-serifed-capped.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothed-inward-serifed-capped.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothless-corner-serifless-hookless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothless-corner-serifless-hookless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothless-corner-serifless-hooked.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothless-corner-serifless-hooked.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothless-corner-serifless-capped.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothless-corner-serifless-capped.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-capital-g-toothless-corner-serifed-hookless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothless-corner-serifed-hookless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothless-corner-serifed-hooked.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothless-corner-serifed-hooked.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothless-corner-serifed-capped.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothless-corner-serifed-capped.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothless-corner-inward-serifed-hookless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothless-corner-inward-serifed-hookless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothless-corner-inward-serifed-hooked.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothless-corner-inward-serifed-hooked.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothless-corner-inward-serifed-capped.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothless-corner-inward-serifed-capped.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothless-rounded-serifless-hookless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothless-rounded-serifless-hookless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothless-rounded-serifless-hooked.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothless-rounded-serifless-hooked.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothless-rounded-serifless-capped.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothless-rounded-serifless-capped.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothless-rounded-serifed-hookless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothless-rounded-serifed-hookless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothless-rounded-serifed-hooked.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothless-rounded-serifed-hooked.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothless-rounded-serifed-capped.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothless-rounded-serifed-capped.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td>21</td>
<td>22</td>
<td>23</td>
<td>24</td>
</tr>
<tr>
<td><img src="../images/cv-capital-g-toothless-rounded-inward-serifed-hookless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothless-rounded-inward-serifed-hookless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothless-rounded-inward-serifed-hooked.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothless-rounded-inward-serifed-hooked.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-g-toothless-rounded-inward-serifed-capped.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-g-toothless-rounded-inward-serifed-capped.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>25</td>
<td>26</td>
<td>27</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv18</code></td>
<td><img src="../images/cv-capital-h-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-h-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-h-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-h-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-h-top-left-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-h-top-left-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-h-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-h-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="8"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td colspan="8"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv19</code></td>
<td><img src="../images/cv-capital-i-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-i-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-i-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-i-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-i-short-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-i-short-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="4"><code>cv20</code></td>
<td><img src="../images/cv-capital-j-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-j-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-j-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-j-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-j-serifed-both-sides.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-j-serifed-both-sides.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-j-serifed-symmetric.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-j-serifed-symmetric.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-j-flat-hook-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-j-flat-hook-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-j-flat-hook-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-j-flat-hook-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-j-flat-hook-serifed-both-sides.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-j-flat-hook-serifed-both-sides.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-j-flat-hook-serifed-symmetric.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-j-flat-hook-serifed-symmetric.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-j-descending-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-j-descending-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-j-descending-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-j-descending-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-j-descending-serifed-both-sides.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-j-descending-serifed-both-sides.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-j-descending-serifed-symmetric.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-j-descending-serifed-symmetric.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-capital-j-descending-flat-hook-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-j-descending-flat-hook-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-j-descending-flat-hook-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-j-descending-flat-hook-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="10"> </td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td colspan="10"> </td>
</tr>
<tr>
<td rowspan="6"><code>cv21</code></td>
<td><img src="../images/cv-capital-k-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-straight-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-straight-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-straight-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-straight-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-straight-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-straight-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-curly-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-curly-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-curly-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-curly-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-curly-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-curly-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-symmetric-touching-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-symmetric-touching-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-symmetric-touching-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-symmetric-touching-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-capital-k-symmetric-touching-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-symmetric-touching-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-symmetric-touching-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-symmetric-touching-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-symmetric-touching-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-symmetric-touching-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-symmetric-connected-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-symmetric-connected-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-symmetric-connected-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-symmetric-connected-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-symmetric-connected-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-symmetric-connected-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-symmetric-connected-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-symmetric-connected-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-symmetric-connected-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-symmetric-connected-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-straight-top-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-straight-top-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-straight-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-straight-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-straight-full-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-straight-full-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-curly-top-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-curly-top-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td>21</td>
<td>22</td>
<td>23</td>
<td>24</td>
</tr>
<tr>
<td><img src="../images/cv-capital-k-curly-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-curly-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-curly-full-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-curly-full-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-symmetric-touching-top-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-symmetric-touching-top-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-symmetric-touching-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-symmetric-touching-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-symmetric-touching-full-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-symmetric-touching-full-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-symmetric-connected-top-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-symmetric-connected-top-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-symmetric-connected-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-symmetric-connected-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-k-symmetric-connected-full-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-k-symmetric-connected-full-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="4"> </td>
</tr>
<tr>
<td>25</td>
<td>26</td>
<td>27</td>
<td>28</td>
<td>29</td>
<td>30</td>
<td>31</td>
<td>32</td>
<td colspan="4"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv22</code></td>
<td><img src="../images/cv-capital-l-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-l-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-l-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-l-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-l-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-l-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv23</code></td>
<td><img src="../images/cv-capital-m-hanging-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-m-hanging-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-m-hanging-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-m-hanging-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-m-hanging-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-m-hanging-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-m-flat-bottom-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-m-flat-bottom-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-m-flat-bottom-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-m-flat-bottom-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-m-flat-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-m-flat-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-m-slanted-sides-hanging-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-m-slanted-sides-hanging-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-m-slanted-sides-hanging-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-m-slanted-sides-hanging-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-m-slanted-sides-hanging-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-m-slanted-sides-hanging-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-m-slanted-sides-flat-bottom-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-m-slanted-sides-flat-bottom-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-m-slanted-sides-flat-bottom-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-m-slanted-sides-flat-bottom-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-m-slanted-sides-flat-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-m-slanted-sides-flat-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td rowspan="2"><code>cv24</code></td>
<td><img src="../images/cv-capital-n-standard-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-n-standard-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-n-standard-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-n-standard-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-n-standard-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-n-standard-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-n-asymmetric-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-n-asymmetric-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-n-asymmetric-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-n-asymmetric-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-n-asymmetric-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-n-asymmetric-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv25</code></td>
<td><img src="../images/cv-capital-p-closed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-p-closed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-p-closed-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-p-closed-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-p-closed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-p-closed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-p-open-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-p-open-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-p-open-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-p-open-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-p-open-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-p-open-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv26</code></td>
<td><img src="../images/cv-capital-q-curly-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-q-curly-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-q-crossing-curly-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-q-crossing-curly-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-q-straight.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-q-straight.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-q-crossing.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-q-crossing.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-q-crossing-baseline.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-q-crossing-baseline.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-q-vertical-crossing.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-q-vertical-crossing.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-q-horizontal-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-q-horizontal-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-q-detached-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-q-detached-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-q-detached-bend-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-q-detached-bend-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-q-open-swash.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-q-open-swash.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-q-closed-swash.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-q-closed-swash.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="1"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td colspan="1"> </td>
</tr>
<tr>
<td rowspan="6"><code>cv27</code></td>
<td><img src="../images/cv-capital-r-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-straight-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-straight-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-straight-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-straight-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-straight-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-straight-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-straight-open-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-straight-open-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-straight-open-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-straight-open-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-straight-open-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-straight-open-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-straight-open-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-straight-open-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-straight-open-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-straight-open-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-curly-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-curly-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-capital-r-curly-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-curly-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-curly-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-curly-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-curly-open-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-curly-open-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-curly-open-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-curly-open-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-curly-open-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-curly-open-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-curly-open-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-curly-open-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-curly-open-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-curly-open-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-standing-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-standing-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-standing-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-standing-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-standing-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-standing-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-standing-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-standing-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td>21</td>
<td>22</td>
<td>23</td>
<td>24</td>
</tr>
<tr>
<td><img src="../images/cv-capital-r-standing-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-standing-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-standing-open-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-standing-open-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-standing-open-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-standing-open-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-standing-open-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-standing-open-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-standing-open-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-standing-open-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-r-standing-open-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-r-standing-open-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td>25</td>
<td>26</td>
<td>27</td>
<td>28</td>
<td>29</td>
<td>30</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv28</code></td>
<td><img src="../images/cv-capital-s-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-s-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-s-unilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-s-unilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-s-bilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-s-bilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-s-unilateral-inward-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-s-unilateral-inward-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-s-bilateral-inward-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-s-bilateral-inward-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="7"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td colspan="7"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv29</code></td>
<td><img src="../images/cv-capital-t-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-t-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-t-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-t-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-t-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-t-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="4"><code>cv30</code></td>
<td><img src="../images/cv-capital-u-toothed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-u-toothed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-u-toothed-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-u-toothed-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-u-toothed-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-u-toothed-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-u-toothed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-u-toothed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-u-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-u-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-u-tailed-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-u-tailed-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-u-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-u-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-u-toothless-corner-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-u-toothless-corner-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-u-toothless-corner-unilateral-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-u-toothless-corner-unilateral-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-u-toothless-corner-bilateral-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-u-toothless-corner-bilateral-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-u-toothless-corner-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-u-toothless-corner-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-u-toothless-rounded-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-u-toothless-rounded-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-capital-u-toothless-rounded-unilateral-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-u-toothless-rounded-unilateral-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-u-toothless-rounded-bilateral-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-u-toothless-rounded-bilateral-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-u-toothless-rounded-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-u-toothless-rounded-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv31</code></td>
<td><img src="../images/cv-capital-v-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-v-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-v-straight-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-v-straight-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-v-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-v-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-v-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-v-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-v-curly-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-v-curly-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-v-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-v-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="6"><code>cv32</code></td>
<td><img src="../images/cv-capital-w-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-straight-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-straight-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-straight-almost-flat-top-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-straight-almost-flat-top-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-straight-almost-flat-top-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-straight-almost-flat-top-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-straight-almost-flat-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-straight-almost-flat-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-straight-flat-top-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-straight-flat-top-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-straight-flat-top-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-straight-flat-top-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-straight-flat-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-straight-flat-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-straight-double-v-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-straight-double-v-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-straight-double-v-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-straight-double-v-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-straight-double-v-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-straight-double-v-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-capital-w-straight-asymmetric-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-straight-asymmetric-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-straight-asymmetric-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-straight-asymmetric-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-straight-asymmetric-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-straight-asymmetric-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-straight-vertical-sides-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-straight-vertical-sides-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-straight-vertical-sides-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-straight-vertical-sides-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-straight-vertical-sides-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-straight-vertical-sides-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-rounded-vertical-sides-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-rounded-vertical-sides-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-rounded-vertical-sides-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-rounded-vertical-sides-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-rounded-vertical-sides-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-rounded-vertical-sides-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-curly-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-curly-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td>21</td>
<td>22</td>
<td>23</td>
<td>24</td>
</tr>
<tr>
<td><img src="../images/cv-capital-w-straight-vertical-sides-flat-top-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-straight-vertical-sides-flat-top-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-straight-vertical-sides-flat-top-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-straight-vertical-sides-flat-top-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-straight-vertical-sides-flat-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-straight-vertical-sides-flat-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-rounded-vertical-sides-flat-top-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-rounded-vertical-sides-flat-top-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-rounded-vertical-sides-flat-top-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-rounded-vertical-sides-flat-top-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-rounded-vertical-sides-flat-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-rounded-vertical-sides-flat-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-curly-almost-flat-top-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-curly-almost-flat-top-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-curly-almost-flat-top-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-curly-almost-flat-top-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-curly-almost-flat-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-curly-almost-flat-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-curly-flat-top-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-curly-flat-top-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-curly-flat-top-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-curly-flat-top-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-w-curly-flat-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-w-curly-flat-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>25</td>
<td>26</td>
<td>27</td>
<td>28</td>
<td>29</td>
<td>30</td>
<td>31</td>
<td>32</td>
<td>33</td>
<td>34</td>
<td>35</td>
<td>36</td>
</tr>
<tr>
<td rowspan="2"><code>cv33</code></td>
<td><img src="../images/cv-capital-x-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-x-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-x-straight-unilateral-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-x-straight-unilateral-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-x-straight-bilateral-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-x-straight-bilateral-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-x-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-x-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-x-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-x-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-x-curly-unilateral-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-x-curly-unilateral-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-x-curly-bilateral-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-x-curly-bilateral-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-x-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-x-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="4"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td colspan="4"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv34</code></td>
<td><img src="../images/cv-capital-y-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-y-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-y-straight-base-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-y-straight-base-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-y-straight-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-y-straight-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-y-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-y-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-y-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-y-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-y-curly-base-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-y-curly-base-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-y-curly-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-y-curly-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-y-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-y-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="4"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td colspan="4"> </td>
</tr>
<tr>
<td rowspan="6"><code>cv35</code></td>
<td><img src="../images/cv-capital-z-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-straight-serifless-with-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-straight-serifless-with-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-straight-serifless-with-horizontal-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-straight-serifless-with-horizontal-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-straight-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-straight-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-straight-top-serifed-with-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-straight-top-serifed-with-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-straight-top-serifed-with-horizontal-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-straight-top-serifed-with-horizontal-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-straight-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-straight-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-straight-bottom-serifed-with-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-straight-bottom-serifed-with-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-straight-bottom-serifed-with-horizontal-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-straight-bottom-serifed-with-horizontal-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-straight-serifed-with-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-straight-serifed-with-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-straight-serifed-with-horizontal-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-straight-serifed-with-horizontal-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-capital-z-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-curly-serifless-with-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-curly-serifless-with-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-curly-serifless-with-horizontal-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-curly-serifless-with-horizontal-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-curly-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-curly-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-curly-top-serifed-with-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-curly-top-serifed-with-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-curly-top-serifed-with-horizontal-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-curly-top-serifed-with-horizontal-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-curly-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-curly-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-curly-bottom-serifed-with-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-curly-bottom-serifed-with-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-curly-bottom-serifed-with-horizontal-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-curly-bottom-serifed-with-horizontal-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-curly-serifed-with-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-curly-serifed-with-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-curly-serifed-with-horizontal-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-curly-serifed-with-horizontal-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td>21</td>
<td>22</td>
<td>23</td>
<td>24</td>
</tr>
<tr>
<td><img src="../images/cv-capital-z-cursive.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-cursive.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-cursive-with-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-cursive-with-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-z-cursive-with-horizontal-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-z-cursive-with-horizontal-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>25</td>
<td>26</td>
<td>27</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="4"><code>cv36</code></td>
<td><img src="../images/cv-a-double-storey-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-double-storey-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-double-storey-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-double-storey-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-double-storey-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-double-storey-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-double-storey-toothless-corner.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-double-storey-toothless-corner.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-double-storey-toothless-rounded.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-double-storey-toothless-rounded.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-double-storey-hook-inward-serifed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-double-storey-hook-inward-serifed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-double-storey-hook-inward-serifed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-double-storey-hook-inward-serifed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-double-storey-hook-inward-serifed-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-double-storey-hook-inward-serifed-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-double-storey-hook-inward-serifed-toothless-corner.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-double-storey-hook-inward-serifed-toothless-corner.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-double-storey-hook-inward-serifed-toothless-rounded.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-double-storey-hook-inward-serifed-toothless-rounded.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-single-storey-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-single-storey-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-single-storey-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-single-storey-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-a-single-storey-double-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-single-storey-double-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-single-storey-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-single-storey-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-single-storey-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-single-storey-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-single-storey-top-cut-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-single-storey-top-cut-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-single-storey-top-cut-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-single-storey-top-cut-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-single-storey-top-cut-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-single-storey-top-cut-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-single-storey-earless-corner-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-single-storey-earless-corner-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-single-storey-earless-corner-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-single-storey-earless-corner-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-single-storey-earless-corner-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-single-storey-earless-corner-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-single-storey-earless-rounded-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-single-storey-earless-rounded-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-single-storey-earless-rounded-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-single-storey-earless-rounded-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-a-single-storey-earless-rounded-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-a-single-storey-earless-rounded-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td>21</td>
<td>22</td>
<td>23</td>
<td>24</td>
</tr>
<tr>
<td rowspan="2"><code>cv37</code></td>
<td><img src="../images/cv-b-toothed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-b-toothed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-b-toothed-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-b-toothed-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-b-toothed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-b-toothed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-b-bottom-cut-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-b-bottom-cut-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-b-bottom-cut-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-b-bottom-cut-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-b-toothless-corner-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-b-toothless-corner-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-b-toothless-corner-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-b-toothless-corner-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-b-toothless-rounded-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-b-toothless-rounded-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-b-toothless-rounded-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-b-toothless-rounded-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="3"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td colspan="3"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv38</code></td>
<td><img src="../images/cv-c-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-c-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-c-unilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-c-unilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-c-bilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-c-bilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-c-unilateral-inward-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-c-unilateral-inward-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-c-bilateral-inward-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-c-bilateral-inward-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="7"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td colspan="7"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv39</code></td>
<td><img src="../images/cv-d-toothed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-d-toothed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-d-toothed-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-d-toothed-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-d-toothed-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-d-toothed-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-d-toothed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-d-toothed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-d-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-d-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-d-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-d-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-d-toothless-corner-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-d-toothless-corner-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-d-toothless-corner-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-d-toothless-corner-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-d-toothless-rounded-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-d-toothless-rounded-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-d-toothless-rounded-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-d-toothless-rounded-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="2"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td colspan="2"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv40</code></td>
<td><img src="../images/cv-e-flat-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-e-flat-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-e-rounded.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-e-rounded.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="10"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td colspan="10"> </td>
</tr>
<tr>
<td rowspan="4"><code>cv41</code></td>
<td><img src="../images/cv-f-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-f-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-f-serifless-crossbar-at-x-height.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-f-serifless-crossbar-at-x-height.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-f-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-f-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-f-serifed-crossbar-at-x-height.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-f-serifed-crossbar-at-x-height.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-f-extended.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-f-extended.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-f-extended-crossbar-at-x-height.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-f-extended-crossbar-at-x-height.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-f-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-f-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-f-tailed-crossbar-at-x-height.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-f-tailed-crossbar-at-x-height.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-f-diagonal-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-f-diagonal-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-f-diagonal-tailed-crossbar-at-x-height.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-f-diagonal-tailed-crossbar-at-x-height.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-f-flat-hook-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-f-flat-hook-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-f-flat-hook-serifless-crossbar-at-x-height.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-f-flat-hook-serifless-crossbar-at-x-height.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-f-flat-hook-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-f-flat-hook-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-f-flat-hook-serifed-crossbar-at-x-height.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-f-flat-hook-serifed-crossbar-at-x-height.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-f-flat-hook-extended.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-f-flat-hook-extended.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-f-flat-hook-extended-crossbar-at-x-height.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-f-flat-hook-extended-crossbar-at-x-height.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-f-flat-hook-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-f-flat-hook-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-f-flat-hook-tailed-crossbar-at-x-height.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-f-flat-hook-tailed-crossbar-at-x-height.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-f-flat-hook-diagonal-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-f-flat-hook-diagonal-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-f-flat-hook-diagonal-tailed-crossbar-at-x-height.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-f-flat-hook-diagonal-tailed-crossbar-at-x-height.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="4"> </td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td colspan="4"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv42</code></td>
<td><img src="../images/cv-g-double-storey.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-g-double-storey.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-g-double-storey-open.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-g-double-storey-open.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-g-single-storey-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-g-single-storey-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-g-single-storey-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-g-single-storey-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-g-single-storey-top-cut.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-g-single-storey-top-cut.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-g-single-storey-earless-corner.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-g-single-storey-earless-corner.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-g-single-storey-earless-rounded.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-g-single-storey-earless-rounded.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-g-single-storey-flat-hook-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-g-single-storey-flat-hook-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-g-single-storey-flat-hook-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-g-single-storey-flat-hook-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-g-single-storey-flat-hook-top-cut.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-g-single-storey-flat-hook-top-cut.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-g-single-storey-flat-hook-earless-corner.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-g-single-storey-flat-hook-earless-corner.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-g-single-storey-flat-hook-earless-rounded.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-g-single-storey-flat-hook-earless-rounded.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td rowspan="2"><code>cv43</code></td>
<td><img src="../images/cv-h-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-h-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-h-straight-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-h-straight-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-h-straight-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-h-straight-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-h-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-h-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-h-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-h-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-h-tailed-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-h-tailed-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-h-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-h-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="5"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td colspan="5"> </td>
</tr>
<tr>
<td rowspan="4"><code>cv44</code></td>
<td><img src="../images/cv-i-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-i-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-i-hooky.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-i-hooky.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-i-hooky-bottom.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-i-hooky-bottom.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-i-zshaped.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-i-zshaped.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-i-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-i-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-i-serifed-asymmetric.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-i-serifed-asymmetric.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-i-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-i-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-i-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-i-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-i-flat-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-i-flat-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-i-serifed-flat-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-i-serifed-flat-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-i-diagonal-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-i-diagonal-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-i-serifed-diagonal-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-i-serifed-diagonal-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-i-semi-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-i-semi-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-i-serifed-semi-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-i-serifed-semi-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="10"> </td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td colspan="10"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv45</code></td>
<td><img src="../images/cv-j-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-j-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-j-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-j-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-j-straight-line.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-j-straight-line.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-j-hooky.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-j-hooky.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-j-flat-hook-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-j-flat-hook-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-j-flat-hook-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-j-flat-hook-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-j-diagonal-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-j-diagonal-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-j-diagonal-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-j-diagonal-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="4"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td colspan="4"> </td>
</tr>
<tr>
<td rowspan="8"><code>cv46</code></td>
<td><img src="../images/cv-k-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-straight-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-straight-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-straight-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-straight-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-straight-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-straight-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-curly-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-curly-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-curly-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-curly-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-curly-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-curly-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-symmetric-touching-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-symmetric-touching-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-symmetric-touching-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-symmetric-touching-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-k-symmetric-touching-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-symmetric-touching-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-symmetric-touching-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-symmetric-touching-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-symmetric-touching-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-symmetric-touching-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-symmetric-connected-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-symmetric-connected-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-symmetric-connected-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-symmetric-connected-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-symmetric-connected-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-symmetric-connected-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-symmetric-connected-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-symmetric-connected-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-symmetric-connected-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-symmetric-connected-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-cursive-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-cursive-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-cursive-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-cursive-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-cursive-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-cursive-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-cursive-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-cursive-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td>21</td>
<td>22</td>
<td>23</td>
<td>24</td>
</tr>
<tr>
<td><img src="../images/cv-k-cursive-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-cursive-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-diagonal-tailed-cursive-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-diagonal-tailed-cursive-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-diagonal-tailed-cursive-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-diagonal-tailed-cursive-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-straight-top-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-straight-top-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-straight-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-straight-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-straight-full-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-straight-full-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-curly-top-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-curly-top-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-curly-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-curly-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-curly-full-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-curly-full-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-symmetric-touching-top-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-symmetric-touching-top-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-symmetric-touching-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-symmetric-touching-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-symmetric-touching-full-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-symmetric-touching-full-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>25</td>
<td>26</td>
<td>27</td>
<td>28</td>
<td>29</td>
<td>30</td>
<td>31</td>
<td>32</td>
<td>33</td>
<td>34</td>
<td>35</td>
<td>36</td>
</tr>
<tr>
<td><img src="../images/cv-k-symmetric-connected-top-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-symmetric-connected-top-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-symmetric-connected-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-symmetric-connected-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-symmetric-connected-full-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-symmetric-connected-full-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-k-cursive-full-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-k-cursive-full-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="8"> </td>
</tr>
<tr>
<td>37</td>
<td>38</td>
<td>39</td>
<td>40</td>
<td colspan="8"> </td>
</tr>
<tr>
<td rowspan="4"><code>cv47</code></td>
<td><img src="../images/cv-l-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-l-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-l-hooky.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-l-hooky.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-l-hooky-bottom.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-l-hooky-bottom.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-l-zshaped.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-l-zshaped.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-l-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-l-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-l-serifed-asymmetric.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-l-serifed-asymmetric.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-l-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-l-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-l-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-l-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-l-flat-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-l-flat-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-l-serifed-flat-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-l-serifed-flat-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-l-diagonal-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-l-diagonal-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-l-serifed-diagonal-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-l-serifed-diagonal-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-l-semi-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-l-semi-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-l-serifed-semi-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-l-serifed-semi-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="10"> </td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td colspan="10"> </td>
</tr>
<tr>
<td rowspan="8"><code>cv48</code></td>
<td><img src="../images/cv-m-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-tailed-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-tailed-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-short-leg-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-short-leg-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-short-leg-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-short-leg-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-short-leg-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-short-leg-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-short-leg-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-short-leg-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-short-leg-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-short-leg-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-m-short-leg-tailed-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-short-leg-tailed-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-short-leg-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-short-leg-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-corner-double-arch-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-corner-double-arch-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-corner-double-arch-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-corner-double-arch-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-corner-double-arch-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-corner-double-arch-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-corner-double-arch-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-corner-double-arch-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-corner-double-arch-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-corner-double-arch-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-corner-double-arch-short-leg-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-corner-double-arch-short-leg-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-corner-double-arch-short-leg-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-corner-double-arch-short-leg-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-corner-double-arch-short-leg-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-corner-double-arch-short-leg-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-corner-double-arch-short-leg-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-corner-double-arch-short-leg-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-corner-double-arch-short-leg-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-corner-double-arch-short-leg-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td>21</td>
<td>22</td>
<td>23</td>
<td>24</td>
</tr>
<tr>
<td><img src="../images/cv-m-earless-rounded-double-arch-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-rounded-double-arch-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-rounded-double-arch-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-rounded-double-arch-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-rounded-double-arch-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-rounded-double-arch-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-rounded-double-arch-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-rounded-double-arch-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-rounded-double-arch-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-rounded-double-arch-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-rounded-double-arch-short-leg-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-rounded-double-arch-short-leg-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-rounded-double-arch-short-leg-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-rounded-double-arch-short-leg-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-rounded-double-arch-short-leg-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-rounded-double-arch-short-leg-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-rounded-double-arch-short-leg-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-rounded-double-arch-short-leg-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-rounded-double-arch-short-leg-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-rounded-double-arch-short-leg-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-single-arch-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-single-arch-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-single-arch-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-single-arch-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>25</td>
<td>26</td>
<td>27</td>
<td>28</td>
<td>29</td>
<td>30</td>
<td>31</td>
<td>32</td>
<td>33</td>
<td>34</td>
<td>35</td>
<td>36</td>
</tr>
<tr>
<td><img src="../images/cv-m-earless-single-arch-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-single-arch-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-single-arch-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-single-arch-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-single-arch-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-single-arch-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-single-arch-short-leg-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-single-arch-short-leg-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-single-arch-short-leg-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-single-arch-short-leg-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-single-arch-short-leg-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-single-arch-short-leg-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-single-arch-short-leg-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-single-arch-short-leg-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-m-earless-single-arch-short-leg-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-m-earless-single-arch-short-leg-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="4"> </td>
</tr>
<tr>
<td>37</td>
<td>38</td>
<td>39</td>
<td>40</td>
<td>41</td>
<td>42</td>
<td>43</td>
<td>44</td>
<td colspan="4"> </td>
</tr>
<tr>
<td rowspan="4"><code>cv49</code></td>
<td><img src="../images/cv-n-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-n-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-n-straight-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-n-straight-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-n-straight-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-n-straight-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-n-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-n-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-n-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-n-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-n-tailed-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-n-tailed-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-n-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-n-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-n-earless-corner-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-n-earless-corner-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-n-earless-corner-straight-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-n-earless-corner-straight-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-n-earless-corner-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-n-earless-corner-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-n-earless-corner-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-n-earless-corner-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-n-earless-corner-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-n-earless-corner-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-n-earless-rounded-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-n-earless-rounded-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-n-earless-rounded-straight-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-n-earless-rounded-straight-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-n-earless-rounded-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-n-earless-rounded-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-n-earless-rounded-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-n-earless-rounded-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-n-earless-rounded-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-n-earless-rounded-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="7"> </td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td colspan="7"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv50</code></td>
<td><img src="../images/cv-p-eared-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-p-eared-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-p-eared-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-p-eared-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-p-eared-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-p-eared-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-p-earless-corner-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-p-earless-corner-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-p-earless-corner-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-p-earless-corner-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-p-earless-rounded-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-p-earless-rounded-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-p-earless-rounded-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-p-earless-rounded-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="5"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td colspan="5"> </td>
</tr>
<tr>
<td rowspan="4"><code>cv51</code></td>
<td><img src="../images/cv-q-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-q-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-q-straight-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-q-straight-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-q-straight-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-q-straight-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-q-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-q-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-q-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-q-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-q-tailed-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-q-tailed-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-q-diagonal-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-q-diagonal-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-q-diagonal-tailed-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-q-diagonal-tailed-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-q-top-cut-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-q-top-cut-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-q-top-cut-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-q-top-cut-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-q-top-cut-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-q-top-cut-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-q-top-cut-diagonal-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-q-top-cut-diagonal-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-q-earless-corner-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-q-earless-corner-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-q-earless-corner-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-q-earless-corner-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-q-earless-corner-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-q-earless-corner-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-q-earless-corner-diagonal-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-q-earless-corner-diagonal-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-q-earless-rounded-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-q-earless-rounded-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-q-earless-rounded-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-q-earless-rounded-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-q-earless-rounded-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-q-earless-rounded-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-q-earless-rounded-diagonal-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-q-earless-rounded-diagonal-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="4"> </td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td colspan="4"> </td>
</tr>
<tr>
<td rowspan="4"><code>cv52</code></td>
<td><img src="../images/cv-r-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-r-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-r-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-r-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-r-base-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-r-base-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-r-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-r-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-r-earless-corner-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-r-earless-corner-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-r-earless-corner-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-r-earless-corner-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-r-earless-rounded-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-r-earless-rounded-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-r-earless-rounded-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-r-earless-rounded-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-r-hookless-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-r-hookless-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-r-hookless-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-r-hookless-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-r-hookless-base-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-r-hookless-base-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-r-hookless-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-r-hookless-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-r-corner-hooked-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-r-corner-hooked-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-r-corner-hooked-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-r-corner-hooked-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-r-corner-hooked-base-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-r-corner-hooked-base-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-r-corner-hooked-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-r-corner-hooked-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-r-compact-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-r-compact-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-r-compact-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-r-compact-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-r-compact-base-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-r-compact-base-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-r-compact-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-r-compact-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="4"> </td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td colspan="4"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv53</code></td>
<td><img src="../images/cv-s-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-s-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-s-unilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-s-unilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-s-bilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-s-bilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-s-unilateral-inward-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-s-unilateral-inward-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-s-bilateral-inward-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-s-bilateral-inward-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="7"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td colspan="7"> </td>
</tr>
<tr>
<td rowspan="4"><code>cv54</code></td>
<td><img src="../images/cv-t-bent-hook.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-bent-hook.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-bent-hook-short-neck.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-bent-hook-short-neck.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-bent-hook-short-neck2.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-bent-hook-short-neck2.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-bent-hook-asymmetric.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-bent-hook-asymmetric.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-bent-hook-asymmetric-short-neck.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-bent-hook-asymmetric-short-neck.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-bent-hook-asymmetric-short-neck2.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-bent-hook-asymmetric-short-neck2.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-flat-hook.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-flat-hook.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-flat-hook-short-neck.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-flat-hook-short-neck.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-flat-hook-short-neck2.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-flat-hook-short-neck2.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-flat-hook-asymmetric.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-flat-hook-asymmetric.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-flat-hook-asymmetric-short-neck.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-flat-hook-asymmetric-short-neck.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-flat-hook-asymmetric-short-neck2.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-flat-hook-asymmetric-short-neck2.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-t-diagonal-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-diagonal-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-diagonal-tailed-short-neck.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-diagonal-tailed-short-neck.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-diagonal-tailed-short-neck2.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-diagonal-tailed-short-neck2.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-diagonal-tailed-asymmetric.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-diagonal-tailed-asymmetric.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-diagonal-tailed-asymmetric-short-neck.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-diagonal-tailed-asymmetric-short-neck.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-diagonal-tailed-asymmetric-short-neck2.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-diagonal-tailed-asymmetric-short-neck2.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-hookless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-hookless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-hookless-short-neck.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-hookless-short-neck.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-hookless-short-neck2.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-hookless-short-neck2.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-hookless-asymmetric.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-hookless-asymmetric.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-hookless-asymmetric-short-neck.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-hookless-asymmetric-short-neck.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-t-hookless-asymmetric-short-neck2.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-t-hookless-asymmetric-short-neck2.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td>21</td>
<td>22</td>
<td>23</td>
<td>24</td>
</tr>
<tr>
<td rowspan="4"><code>cv55</code></td>
<td><img src="../images/cv-u-toothed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-u-toothed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-u-toothed-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-u-toothed-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-u-toothed-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-u-toothed-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-u-toothed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-u-toothed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-u-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-u-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-u-tailed-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-u-tailed-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-u-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-u-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-u-toothless-corner-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-u-toothless-corner-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-u-toothless-corner-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-u-toothless-corner-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-u-toothless-corner-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-u-toothless-corner-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-u-toothless-rounded-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-u-toothless-rounded-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-u-toothless-rounded-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-u-toothless-rounded-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-u-toothless-rounded-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-u-toothless-rounded-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="11"> </td>
</tr>
<tr>
<td>13</td>
<td colspan="11"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv56</code></td>
<td><img src="../images/cv-v-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-v-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-v-straight-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-v-straight-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-v-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-v-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-v-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-v-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-v-curly-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-v-curly-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-v-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-v-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-v-cursive-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-v-cursive-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-v-cursive-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-v-cursive-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="4"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td colspan="4"> </td>
</tr>
<tr>
<td rowspan="8"><code>cv57</code></td>
<td><img src="../images/cv-w-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-straight-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-straight-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-straight-almost-flat-top-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-straight-almost-flat-top-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-straight-almost-flat-top-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-straight-almost-flat-top-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-straight-almost-flat-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-straight-almost-flat-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-straight-flat-top-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-straight-flat-top-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-straight-flat-top-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-straight-flat-top-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-straight-flat-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-straight-flat-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-straight-double-v-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-straight-double-v-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-straight-double-v-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-straight-double-v-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-straight-double-v-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-straight-double-v-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-w-straight-asymmetric-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-straight-asymmetric-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-straight-asymmetric-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-straight-asymmetric-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-straight-asymmetric-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-straight-asymmetric-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-straight-vertical-sides-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-straight-vertical-sides-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-straight-vertical-sides-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-straight-vertical-sides-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-straight-vertical-sides-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-straight-vertical-sides-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-rounded-vertical-sides-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-rounded-vertical-sides-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-rounded-vertical-sides-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-rounded-vertical-sides-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-rounded-vertical-sides-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-rounded-vertical-sides-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-curly-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-curly-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td>21</td>
<td>22</td>
<td>23</td>
<td>24</td>
</tr>
<tr>
<td><img src="../images/cv-w-cursive-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-cursive-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-cursive-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-cursive-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-straight-vertical-sides-flat-top-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-straight-vertical-sides-flat-top-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-straight-vertical-sides-flat-top-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-straight-vertical-sides-flat-top-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-straight-vertical-sides-flat-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-straight-vertical-sides-flat-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-rounded-vertical-sides-flat-top-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-rounded-vertical-sides-flat-top-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-rounded-vertical-sides-flat-top-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-rounded-vertical-sides-flat-top-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-rounded-vertical-sides-flat-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-rounded-vertical-sides-flat-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-curly-almost-flat-top-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-curly-almost-flat-top-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-curly-almost-flat-top-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-curly-almost-flat-top-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-curly-almost-flat-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-curly-almost-flat-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-curly-flat-top-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-curly-flat-top-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>25</td>
<td>26</td>
<td>27</td>
<td>28</td>
<td>29</td>
<td>30</td>
<td>31</td>
<td>32</td>
<td>33</td>
<td>34</td>
<td>35</td>
<td>36</td>
</tr>
<tr>
<td><img src="../images/cv-w-curly-flat-top-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-curly-flat-top-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-w-curly-flat-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-w-curly-flat-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="10"> </td>
</tr>
<tr>
<td>37</td>
<td>38</td>
<td colspan="10"> </td>
</tr>
<tr>
<td rowspan="4"><code>cv58</code></td>
<td><img src="../images/cv-x-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-x-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-x-straight-unilateral-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-x-straight-unilateral-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-x-straight-bilateral-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-x-straight-bilateral-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-x-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-x-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-x-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-x-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-x-curly-unilateral-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-x-curly-unilateral-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-x-curly-bilateral-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-x-curly-bilateral-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-x-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-x-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-x-semi-chancery-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-x-semi-chancery-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-x-semi-chancery-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-x-semi-chancery-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-x-semi-chancery-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-x-semi-chancery-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-x-semi-chancery-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-x-semi-chancery-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-x-chancery.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-x-chancery.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-x-cursive.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-x-cursive.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="10"> </td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td colspan="10"> </td>
</tr>
<tr>
<td rowspan="4"><code>cv59</code></td>
<td><img src="../images/cv-y-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-y-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-y-straight-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-y-straight-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-y-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-y-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-y-straight-turn-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-y-straight-turn-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-y-straight-turn-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-y-straight-turn-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-y-straight-turn-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-y-straight-turn-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-y-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-y-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-y-curly-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-y-curly-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-y-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-y-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-y-curly-turn-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-y-curly-turn-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-y-curly-turn-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-y-curly-turn-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-y-curly-turn-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-y-curly-turn-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-y-cursive-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-y-cursive-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-y-cursive-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-y-cursive-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-y-cursive-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-y-cursive-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-y-cursive-flat-hook-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-y-cursive-flat-hook-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-y-cursive-flat-hook-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-y-cursive-flat-hook-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-y-cursive-flat-hook-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-y-cursive-flat-hook-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="6"><code>cv60</code></td>
<td><img src="../images/cv-z-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-straight-serifless-with-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-straight-serifless-with-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-straight-serifless-with-horizontal-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-straight-serifless-with-horizontal-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-straight-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-straight-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-straight-top-serifed-with-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-straight-top-serifed-with-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-straight-top-serifed-with-horizontal-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-straight-top-serifed-with-horizontal-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-straight-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-straight-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-straight-bottom-serifed-with-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-straight-bottom-serifed-with-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-straight-bottom-serifed-with-horizontal-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-straight-bottom-serifed-with-horizontal-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-straight-serifed-with-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-straight-serifed-with-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-straight-serifed-with-horizontal-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-straight-serifed-with-horizontal-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-z-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-curly-serifless-with-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-curly-serifless-with-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-curly-serifless-with-horizontal-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-curly-serifless-with-horizontal-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-curly-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-curly-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-curly-top-serifed-with-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-curly-top-serifed-with-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-curly-top-serifed-with-horizontal-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-curly-top-serifed-with-horizontal-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-curly-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-curly-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-curly-bottom-serifed-with-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-curly-bottom-serifed-with-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-curly-bottom-serifed-with-horizontal-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-curly-bottom-serifed-with-horizontal-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-curly-serifed-with-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-curly-serifed-with-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-curly-serifed-with-horizontal-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-curly-serifed-with-horizontal-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td>21</td>
<td>22</td>
<td>23</td>
<td>24</td>
</tr>
<tr>
<td><img src="../images/cv-z-cursive.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-cursive.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-cursive-with-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-cursive-with-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-z-cursive-with-horizontal-crossbar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-z-cursive-with-horizontal-crossbar.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>25</td>
<td>26</td>
<td>27</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv61</code></td>
<td><img src="../images/cv-capital-eszet-rounded-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-eszet-rounded-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-eszet-rounded-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-eszet-rounded-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-eszet-flat-top-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-eszet-flat-top-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-eszet-flat-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-eszet-flat-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-eszet-corner-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-eszet-corner-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-eszet-corner-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-eszet-corner-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-eszet-corner-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-eszet-corner-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-eszet-corner-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-eszet-corner-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="4"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td colspan="4"> </td>
</tr>
<tr>
<td rowspan="6"><code>cv62</code></td>
<td><img src="../images/cv-long-s-bent-hook-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-bent-hook-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-bent-hook-middle-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-bent-hook-middle-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-bent-hook-middle-serifed-xh.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-bent-hook-middle-serifed-xh.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-bent-hook-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-bent-hook-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-bent-hook-double-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-bent-hook-double-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-bent-hook-double-serifed-xh.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-bent-hook-double-serifed-xh.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-bent-hook-descending.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-bent-hook-descending.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-bent-hook-descending-middle-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-bent-hook-descending-middle-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-bent-hook-descending-middle-serifed-xh.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-bent-hook-descending-middle-serifed-xh.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-bent-hook-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-bent-hook-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-bent-hook-tailed-middle-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-bent-hook-tailed-middle-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-bent-hook-tailed-middle-serifed-xh.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-bent-hook-tailed-middle-serifed-xh.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-long-s-bent-hook-diagonal-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-bent-hook-diagonal-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-bent-hook-diagonal-tailed-middle-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-bent-hook-diagonal-tailed-middle-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-bent-hook-diagonal-tailed-middle-serifed-xh.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-bent-hook-diagonal-tailed-middle-serifed-xh.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-flat-hook-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-flat-hook-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-flat-hook-middle-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-flat-hook-middle-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-flat-hook-middle-serifed-xh.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-flat-hook-middle-serifed-xh.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-flat-hook-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-flat-hook-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-flat-hook-double-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-flat-hook-double-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-flat-hook-double-serifed-xh.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-flat-hook-double-serifed-xh.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-flat-hook-descending.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-flat-hook-descending.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-flat-hook-descending-middle-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-flat-hook-descending-middle-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-flat-hook-descending-middle-serifed-xh.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-flat-hook-descending-middle-serifed-xh.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td>21</td>
<td>22</td>
<td>23</td>
<td>24</td>
</tr>
<tr>
<td><img src="../images/cv-long-s-flat-hook-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-flat-hook-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-flat-hook-tailed-middle-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-flat-hook-tailed-middle-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-flat-hook-tailed-middle-serifed-xh.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-flat-hook-tailed-middle-serifed-xh.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-flat-hook-diagonal-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-flat-hook-diagonal-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-flat-hook-diagonal-tailed-middle-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-flat-hook-diagonal-tailed-middle-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-long-s-flat-hook-diagonal-tailed-middle-serifed-xh.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-long-s-flat-hook-diagonal-tailed-middle-serifed-xh.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td>25</td>
<td>26</td>
<td>27</td>
<td>28</td>
<td>29</td>
<td>30</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="8"><code>cv63</code></td>
<td><img src="../images/cv-eszet-traditional-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-traditional-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-traditional-middle-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-traditional-middle-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-traditional-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-traditional-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-traditional-dual-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-traditional-dual-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-traditional-descending-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-traditional-descending-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-traditional-descending-middle-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-traditional-descending-middle-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-traditional-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-traditional-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-traditional-tailed-middle-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-traditional-tailed-middle-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-traditional-flat-hook-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-traditional-flat-hook-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-traditional-flat-hook-middle-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-traditional-flat-hook-middle-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-traditional-flat-hook-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-traditional-flat-hook-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-traditional-flat-hook-dual-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-traditional-flat-hook-dual-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-eszet-traditional-flat-hook-descending-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-traditional-flat-hook-descending-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-traditional-flat-hook-descending-middle-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-traditional-flat-hook-descending-middle-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-traditional-flat-hook-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-traditional-flat-hook-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-traditional-flat-hook-tailed-middle-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-traditional-flat-hook-tailed-middle-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-sulzbacher-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-sulzbacher-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-sulzbacher-middle-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-sulzbacher-middle-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-sulzbacher-middle-serifed-xh.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-sulzbacher-middle-serifed-xh.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-sulzbacher-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-sulzbacher-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-sulzbacher-dual-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-sulzbacher-dual-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-sulzbacher-dual-serifed-xh.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-sulzbacher-dual-serifed-xh.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-sulzbacher-descending-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-sulzbacher-descending-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-sulzbacher-descending-middle-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-sulzbacher-descending-middle-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td>21</td>
<td>22</td>
<td>23</td>
<td>24</td>
</tr>
<tr>
<td><img src="../images/cv-eszet-sulzbacher-descending-middle-serifed-xh.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-sulzbacher-descending-middle-serifed-xh.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-sulzbacher-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-sulzbacher-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-sulzbacher-tailed-middle-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-sulzbacher-tailed-middle-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-sulzbacher-tailed-middle-serifed-xh.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-sulzbacher-tailed-middle-serifed-xh.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-longs-s-lig-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-longs-s-lig-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-longs-s-lig-middle-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-longs-s-lig-middle-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-longs-s-lig-middle-serifed-xh.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-longs-s-lig-middle-serifed-xh.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-longs-s-lig-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-longs-s-lig-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-longs-s-lig-dual-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-longs-s-lig-dual-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-longs-s-lig-dual-serifed-xh.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-longs-s-lig-dual-serifed-xh.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-longs-s-lig-descending-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-longs-s-lig-descending-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-longs-s-lig-descending-middle-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-longs-s-lig-descending-middle-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>25</td>
<td>26</td>
<td>27</td>
<td>28</td>
<td>29</td>
<td>30</td>
<td>31</td>
<td>32</td>
<td>33</td>
<td>34</td>
<td>35</td>
<td>36</td>
</tr>
<tr>
<td><img src="../images/cv-eszet-longs-s-lig-descending-middle-serifed-xh.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-longs-s-lig-descending-middle-serifed-xh.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-longs-s-lig-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-longs-s-lig-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-longs-s-lig-tailed-middle-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-longs-s-lig-tailed-middle-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-eszet-longs-s-lig-tailed-middle-serifed-xh.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-eszet-longs-s-lig-tailed-middle-serifed-xh.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="8"> </td>
</tr>
<tr>
<td>37</td>
<td>38</td>
<td>39</td>
<td>40</td>
<td colspan="8"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv64</code></td>
<td><img src="../images/cv-lower-eth-straight-bar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-eth-straight-bar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-eth-curly-bar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-eth-curly-bar.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="10"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td colspan="10"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv65</code></td>
<td><img src="../images/cv-capital-thorn-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-thorn-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-thorn-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-thorn-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-thorn-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-thorn-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-thorn-asymmetric-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-thorn-asymmetric-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-thorn-asymmetric-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-thorn-asymmetric-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-thorn-asymmetric-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-thorn-asymmetric-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv66</code></td>
<td><img src="../images/cv-lower-thorn-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-thorn-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-thorn-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-thorn-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-thorn-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-thorn-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="4"><code>cv67</code></td>
<td><img src="../images/cv-lower-alpha-crossing.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-alpha-crossing.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-alpha-barred.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-alpha-barred.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-alpha-barred-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-alpha-barred-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-alpha-barred-double-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-alpha-barred-double-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-alpha-barred-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-alpha-barred-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-alpha-barred-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-alpha-barred-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-alpha-barred-top-cut.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-alpha-barred-top-cut.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-alpha-barred-top-cut-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-alpha-barred-top-cut-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-alpha-barred-top-cut-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-alpha-barred-top-cut-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-alpha-barred-earless-corner.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-alpha-barred-earless-corner.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-alpha-barred-earless-corner-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-alpha-barred-earless-corner-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-alpha-barred-earless-corner-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-alpha-barred-earless-corner-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-lower-alpha-barred-earless-rounded.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-alpha-barred-earless-rounded.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-alpha-barred-earless-rounded-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-alpha-barred-earless-rounded-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-alpha-barred-earless-rounded-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-alpha-barred-earless-rounded-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv68</code></td>
<td><img src="../images/cv-lower-beta-standard.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-beta-standard.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-beta-cursive.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-beta-cursive.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="10"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td colspan="10"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv69</code></td>
<td><img src="../images/cv-capital-gamma-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-gamma-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-gamma-top-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-gamma-top-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-gamma-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-gamma-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-gamma-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-gamma-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="8"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td colspan="8"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv70</code></td>
<td><img src="../images/cv-lower-gamma-straight.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-gamma-straight.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-gamma-curly.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-gamma-curly.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-gamma-casual.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-gamma-casual.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv71</code></td>
<td><img src="../images/cv-capital-delta-straight.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-delta-straight.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-delta-curly.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-delta-curly.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="10"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td colspan="10"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv72</code></td>
<td><img src="../images/cv-lower-delta-rounded.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-delta-rounded.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-delta-flat-top.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-delta-flat-top.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="10"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td colspan="10"> </td>
</tr>
<tr>
<td rowspan="2"><code>VXAA</code></td>
<td><img src="../images/cv-lower-eta-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-eta-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-eta-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-eta-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-eta-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-eta-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-eta-earless-corner-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-eta-earless-corner-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-eta-earless-corner-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-eta-earless-corner-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-eta-earless-rounded-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-eta-earless-rounded-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-eta-earless-rounded-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-eta-earless-rounded-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="5"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td colspan="5"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv73</code></td>
<td><img src="../images/cv-lower-theta-capsule.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-theta-capsule.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-theta-oval.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-theta-oval.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-theta-diamond.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-theta-diamond.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-theta-cursive.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-theta-cursive.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="8"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td colspan="8"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv74</code></td>
<td><img src="../images/cv-lower-iota-tailless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-iota-tailless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-iota-tailless-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-iota-tailless-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-iota-hooky-bottom.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-iota-hooky-bottom.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-iota-zshaped.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-iota-zshaped.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-iota-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-iota-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-iota-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-iota-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-iota-flat-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-iota-flat-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-iota-serifed-flat-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-iota-serifed-flat-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-iota-diagonal-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-iota-diagonal-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-iota-serifed-diagonal-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-iota-serifed-diagonal-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-iota-semi-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-iota-semi-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-iota-serifed-semi-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-iota-serifed-semi-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td rowspan="6"><code>VXAB</code></td>
<td><img src="../images/cv-lower-kappa-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-straight-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-straight-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-straight-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-straight-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-straight-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-straight-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-straight-top-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-straight-top-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-straight-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-straight-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-straight-full-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-straight-full-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-curly-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-curly-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-curly-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-curly-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-curly-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-curly-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-lower-kappa-curly-top-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-curly-top-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-curly-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-curly-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-curly-full-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-curly-full-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-symmetric-touching-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-symmetric-touching-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-symmetric-touching-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-symmetric-touching-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-symmetric-touching-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-symmetric-touching-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-symmetric-touching-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-symmetric-touching-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-symmetric-touching-top-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-symmetric-touching-top-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-symmetric-touching-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-symmetric-touching-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-symmetric-touching-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-symmetric-touching-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-symmetric-touching-full-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-symmetric-touching-full-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td>21</td>
<td>22</td>
<td>23</td>
<td>24</td>
</tr>
<tr>
<td><img src="../images/cv-lower-kappa-symmetric-connected-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-symmetric-connected-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-symmetric-connected-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-symmetric-connected-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-symmetric-connected-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-symmetric-connected-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-symmetric-connected-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-symmetric-connected-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-symmetric-connected-top-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-symmetric-connected-top-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-symmetric-connected-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-symmetric-connected-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-symmetric-connected-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-symmetric-connected-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-kappa-symmetric-connected-full-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-kappa-symmetric-connected-full-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="4"> </td>
</tr>
<tr>
<td>25</td>
<td>26</td>
<td>27</td>
<td>28</td>
<td>29</td>
<td>30</td>
<td>31</td>
<td>32</td>
<td colspan="4"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv75</code></td>
<td><img src="../images/cv-capital-lambda-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-lambda-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-lambda-straight-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-lambda-straight-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-lambda-straight-base-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-lambda-straight-base-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-lambda-straight-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-lambda-straight-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-lambda-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-lambda-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-lambda-curly-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-lambda-curly-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-lambda-curly-base-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-lambda-curly-base-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-capital-lambda-curly-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-capital-lambda-curly-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="4"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td colspan="4"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv76</code></td>
<td><img src="../images/cv-lower-lambda-straight.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-lambda-straight.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-lambda-straight-turn.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-lambda-straight-turn.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-lambda-tailed-turn.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-lambda-tailed-turn.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-lambda-curly.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-lambda-curly.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-lambda-curly-turn.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-lambda-curly-turn.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-lambda-curly-tailed-turn.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-lambda-curly-tailed-turn.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="4"><code>cv77</code></td>
<td><img src="../images/cv-lower-mu-toothed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-mu-toothed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-mu-toothed-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-mu-toothed-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-mu-toothed-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-mu-toothed-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-mu-toothed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-mu-toothed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-mu-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-mu-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-mu-tailed-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-mu-tailed-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-mu-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-mu-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-mu-toothless-corner-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-mu-toothless-corner-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-mu-toothless-corner-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-mu-toothless-corner-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-mu-toothless-corner-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-mu-toothless-corner-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-mu-toothless-rounded-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-mu-toothless-rounded-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-mu-toothless-rounded-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-mu-toothless-rounded-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-lower-mu-toothless-rounded-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-mu-toothless-rounded-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="11"> </td>
</tr>
<tr>
<td>13</td>
<td colspan="11"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv78</code></td>
<td><img src="../images/cv-lower-nu-straight.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-nu-straight.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-nu-curly.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-nu-curly.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-nu-casual.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-nu-casual.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv79</code></td>
<td><img src="../images/cv-lower-xi-rounded.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-xi-rounded.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-xi-flat-top.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-xi-flat-top.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="10"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td colspan="10"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv80</code></td>
<td><img src="../images/cv-lower-pi-tailless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-pi-tailless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-pi-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-pi-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-pi-small-capital.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-pi-small-capital.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv81</code></td>
<td><img src="../images/cv-lower-tau-tailless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-tau-tailless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-tau-short-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-tau-short-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-tau-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-tau-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-tau-flat-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-tau-flat-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-tau-diagonal-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-tau-diagonal-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-tau-semi-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-tau-semi-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv82</code></td>
<td><img src="../images/cv-lower-upsilon-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-upsilon-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-upsilon-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-upsilon-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-upsilon-casual-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-upsilon-casual-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-upsilon-casual-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-upsilon-casual-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="8"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td colspan="8"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv83</code></td>
<td><img src="../images/cv-lower-phi-straight.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-phi-straight.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-phi-cursive.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-phi-cursive.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-phi-neo-hellenic.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-phi-neo-hellenic.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="4"><code>cv84</code></td>
<td><img src="../images/cv-lower-chi-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-chi-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-chi-straight-unilateral-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-chi-straight-unilateral-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-chi-straight-bilateral-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-chi-straight-bilateral-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-chi-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-chi-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-chi-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-chi-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-chi-curly-unilateral-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-chi-curly-unilateral-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-chi-curly-bilateral-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-chi-curly-bilateral-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-chi-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-chi-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-chi-semi-chancery-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-chi-semi-chancery-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-chi-semi-chancery-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-chi-semi-chancery-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-chi-semi-chancery-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-chi-semi-chancery-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-chi-semi-chancery-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-chi-semi-chancery-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-lower-chi-chancery.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-chi-chancery.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="11"> </td>
</tr>
<tr>
<td>13</td>
<td colspan="11"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv85</code></td>
<td><img src="../images/cv-lower-psi-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-psi-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-psi-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-psi-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-psi-flat-top-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-psi-flat-top-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lower-psi-flat-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lower-psi-flat-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="8"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td colspan="8"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv86</code></td>
<td><img src="../images/cv-partial-derivative-straight-bar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-partial-derivative-straight-bar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-partial-derivative-curly-bar.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-partial-derivative-curly-bar.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-partial-derivative-closed-contour.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-partial-derivative-closed-contour.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="4"><code>cv87</code></td>
<td><img src="../images/cv-cyrl-a-double-storey-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-double-storey-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-double-storey-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-double-storey-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-double-storey-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-double-storey-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-double-storey-toothless-corner.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-double-storey-toothless-corner.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-double-storey-toothless-rounded.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-double-storey-toothless-rounded.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-double-storey-hook-inward-serifed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-double-storey-hook-inward-serifed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-double-storey-hook-inward-serifed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-double-storey-hook-inward-serifed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-double-storey-hook-inward-serifed-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-double-storey-hook-inward-serifed-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-double-storey-hook-inward-serifed-toothless-corner.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-double-storey-hook-inward-serifed-toothless-corner.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-double-storey-hook-inward-serifed-toothless-rounded.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-double-storey-hook-inward-serifed-toothless-rounded.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-single-storey-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-single-storey-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-single-storey-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-single-storey-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-cyrl-a-single-storey-double-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-single-storey-double-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-single-storey-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-single-storey-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-single-storey-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-single-storey-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-single-storey-top-cut-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-single-storey-top-cut-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-single-storey-top-cut-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-single-storey-top-cut-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-single-storey-top-cut-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-single-storey-top-cut-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-single-storey-earless-corner-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-single-storey-earless-corner-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-single-storey-earless-corner-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-single-storey-earless-corner-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-single-storey-earless-corner-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-single-storey-earless-corner-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-single-storey-earless-rounded-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-single-storey-earless-rounded-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-single-storey-earless-rounded-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-single-storey-earless-rounded-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-a-single-storey-earless-rounded-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-a-single-storey-earless-rounded-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td>21</td>
<td>22</td>
<td>23</td>
<td>24</td>
</tr>
<tr>
<td rowspan="2"><code>cv88</code></td>
<td><img src="../images/cv-cyrl-ve-standard-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ve-standard-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ve-standard-unilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ve-standard-unilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ve-standard-bilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ve-standard-bilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ve-standard-interrupted-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ve-standard-interrupted-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ve-standard-interrupted-unilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ve-standard-interrupted-unilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ve-standard-interrupted-bilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ve-standard-interrupted-bilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ve-cursive.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ve-cursive.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ve-cursive-tall.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ve-cursive-tall.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="4"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td colspan="4"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv89</code></td>
<td><img src="../images/cv-cyrl-capital-zhe-straight.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-zhe-straight.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-zhe-curly.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-zhe-curly.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-zhe-symmetric-touching.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-zhe-symmetric-touching.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-zhe-symmetric-connected.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-zhe-symmetric-connected.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-zhe-cursive.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-zhe-cursive.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="7"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td colspan="7"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv90</code></td>
<td><img src="../images/cv-cyrl-zhe-straight.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-zhe-straight.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-zhe-curly.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-zhe-curly.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-zhe-symmetric-touching.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-zhe-symmetric-touching.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-zhe-symmetric-connected.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-zhe-symmetric-connected.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-zhe-cursive.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-zhe-cursive.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="7"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td colspan="7"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv91</code></td>
<td><img src="../images/cv-cyrl-capital-ze-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ze-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ze-unilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ze-unilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ze-unilateral-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ze-unilateral-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ze-bilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ze-bilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ze-unilateral-inward-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ze-unilateral-inward-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ze-unilateral-bottom-inward-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ze-unilateral-bottom-inward-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ze-bilateral-inward-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ze-bilateral-inward-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="5"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td colspan="5"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv92</code></td>
<td><img src="../images/cv-cyrl-ze-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ze-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ze-unilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ze-unilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ze-unilateral-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ze-unilateral-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ze-bilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ze-bilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ze-unilateral-inward-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ze-unilateral-inward-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ze-unilateral-bottom-inward-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ze-unilateral-bottom-inward-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ze-bilateral-inward-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ze-bilateral-inward-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="5"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td colspan="5"> </td>
</tr>
<tr>
<td rowspan="6"><code>cv93</code></td>
<td><img src="../images/cv-cyrl-capital-ka-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-straight-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-straight-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-straight-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-straight-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-straight-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-straight-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-curly-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-curly-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-curly-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-curly-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-curly-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-curly-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-symmetric-touching-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-symmetric-touching-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-symmetric-touching-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-symmetric-touching-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-cyrl-capital-ka-symmetric-touching-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-symmetric-touching-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-symmetric-touching-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-symmetric-touching-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-symmetric-touching-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-symmetric-touching-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-symmetric-connected-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-symmetric-connected-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-symmetric-connected-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-symmetric-connected-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-symmetric-connected-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-symmetric-connected-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-symmetric-connected-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-symmetric-connected-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-symmetric-connected-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-symmetric-connected-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-straight-top-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-straight-top-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-straight-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-straight-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-curly-top-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-curly-top-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-curly-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-curly-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td>21</td>
<td>22</td>
<td>23</td>
<td>24</td>
</tr>
<tr>
<td><img src="../images/cv-cyrl-capital-ka-symmetric-touching-top-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-symmetric-touching-top-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-symmetric-touching-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-symmetric-touching-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-symmetric-connected-top-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-symmetric-connected-top-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ka-symmetric-connected-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ka-symmetric-connected-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="8"> </td>
</tr>
<tr>
<td>25</td>
<td>26</td>
<td>27</td>
<td>28</td>
<td colspan="8"> </td>
</tr>
<tr>
<td rowspan="6"><code>cv94</code></td>
<td><img src="../images/cv-cyrl-ka-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-straight-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-straight-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-straight-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-straight-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-straight-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-straight-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-curly-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-curly-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-curly-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-curly-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-curly-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-curly-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-symmetric-touching-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-symmetric-touching-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-symmetric-touching-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-symmetric-touching-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-cyrl-ka-symmetric-touching-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-symmetric-touching-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-symmetric-touching-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-symmetric-touching-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-symmetric-touching-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-symmetric-touching-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-symmetric-connected-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-symmetric-connected-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-symmetric-connected-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-symmetric-connected-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-symmetric-connected-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-symmetric-connected-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-symmetric-connected-top-left-and-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-symmetric-connected-top-left-and-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-symmetric-connected-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-symmetric-connected-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-straight-top-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-straight-top-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-straight-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-straight-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-curly-top-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-curly-top-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-curly-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-curly-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td>21</td>
<td>22</td>
<td>23</td>
<td>24</td>
</tr>
<tr>
<td><img src="../images/cv-cyrl-ka-symmetric-touching-top-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-symmetric-touching-top-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-symmetric-touching-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-symmetric-touching-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-symmetric-connected-top-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-symmetric-connected-top-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ka-symmetric-connected-tri-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ka-symmetric-connected-tri-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="8"> </td>
</tr>
<tr>
<td>25</td>
<td>26</td>
<td>27</td>
<td>28</td>
<td colspan="8"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv95</code></td>
<td><img src="../images/cv-cyrl-el-straight.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-el-straight.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-el-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-el-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="10"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td colspan="10"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv96</code></td>
<td><img src="../images/cv-cyrl-em-hanging-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-em-hanging-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-em-hanging-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-em-hanging-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-em-hanging-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-em-hanging-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-em-flat-bottom-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-em-flat-bottom-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-em-flat-bottom-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-em-flat-bottom-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-em-flat-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-em-flat-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-em-slanted-sides-hanging-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-em-slanted-sides-hanging-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-em-slanted-sides-hanging-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-em-slanted-sides-hanging-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-em-slanted-sides-hanging-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-em-slanted-sides-hanging-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-em-slanted-sides-flat-bottom-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-em-slanted-sides-flat-bottom-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-em-slanted-sides-flat-bottom-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-em-slanted-sides-flat-bottom-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-em-slanted-sides-flat-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-em-slanted-sides-flat-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td rowspan="2"><code>cv97</code></td>
<td><img src="../images/cv-cyrl-capital-en-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-en-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-en-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-en-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-en-top-left-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-en-top-left-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-en-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-en-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="8"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td colspan="8"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv98</code></td>
<td><img src="../images/cv-cyrl-en-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-en-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-en-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-en-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-en-top-left-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-en-top-left-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-en-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-en-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-en-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-en-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-en-tailed-top-left-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-en-tailed-top-left-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-en-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-en-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="5"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td colspan="5"> </td>
</tr>
<tr>
<td rowspan="2"><code>cv99</code></td>
<td><img src="../images/cv-cyrl-capital-er-closed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-er-closed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-er-closed-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-er-closed-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-er-closed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-er-closed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-er-open-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-er-open-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-er-open-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-er-open-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-er-open-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-er-open-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="2"><code>VAAA</code></td>
<td><img src="../images/cv-cyrl-er-eared-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-er-eared-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-er-eared-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-er-eared-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-er-eared-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-er-eared-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-er-earless-corner-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-er-earless-corner-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-er-earless-corner-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-er-earless-corner-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-er-earless-rounded-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-er-earless-rounded-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-er-earless-rounded-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-er-earless-rounded-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="5"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td colspan="5"> </td>
</tr>
<tr>
<td rowspan="4"><code>VAAB</code></td>
<td><img src="../images/cv-cyrl-capital-u-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-u-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-u-straight-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-u-straight-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-u-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-u-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-u-straight-turn-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-u-straight-turn-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-u-straight-turn-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-u-straight-turn-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-u-straight-turn-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-u-straight-turn-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-u-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-u-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-u-curly-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-u-curly-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-u-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-u-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-u-curly-turn-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-u-curly-turn-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-u-curly-turn-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-u-curly-turn-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-u-curly-turn-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-u-curly-turn-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-cyrl-capital-u-cursive-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-u-cursive-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-u-cursive-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-u-cursive-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-u-cursive-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-u-cursive-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-u-cursive-flat-hook-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-u-cursive-flat-hook-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-u-cursive-flat-hook-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-u-cursive-flat-hook-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-u-cursive-flat-hook-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-u-cursive-flat-hook-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="4"><code>VAAC</code></td>
<td><img src="../images/cv-cyrl-u-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-u-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-u-straight-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-u-straight-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-u-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-u-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-u-straight-turn-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-u-straight-turn-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-u-straight-turn-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-u-straight-turn-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-u-straight-turn-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-u-straight-turn-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-u-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-u-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-u-curly-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-u-curly-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-u-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-u-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-u-curly-turn-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-u-curly-turn-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-u-curly-turn-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-u-curly-turn-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-u-curly-turn-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-u-curly-turn-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-cyrl-u-cursive-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-u-cursive-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-u-cursive-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-u-cursive-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-u-cursive-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-u-cursive-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-u-cursive-flat-hook-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-u-cursive-flat-hook-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-u-cursive-flat-hook-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-u-cursive-flat-hook-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-u-cursive-flat-hook-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-u-cursive-flat-hook-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="2"><code>VAAD</code></td>
<td><img src="../images/cv-cyrl-ef-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ef-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ef-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ef-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ef-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ef-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ef-cursive.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ef-cursive.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ef-diagonal-tailed-cursive.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ef-diagonal-tailed-cursive.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ef-split-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ef-split-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ef-split-top-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ef-split-top-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ef-split-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ef-split-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ef-split-cursive.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ef-split-cursive.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ef-split-diagonal-tailed-cursive.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ef-split-diagonal-tailed-cursive.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="2"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td colspan="2"> </td>
</tr>
<tr>
<td rowspan="2"><code>VAAE</code></td>
<td><img src="../images/cv-cyrl-che-standard.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-che-standard.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-che-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-che-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="10"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td colspan="10"> </td>
</tr>
<tr>
<td rowspan="2"><code>VAAF</code></td>
<td colspan="2"><img src="../images/cv-cyrl-yeri-corner.light.svg#gh-light-mode-only" width=64/><img src="../images/cv-cyrl-yeri-corner.dark.svg#gh-dark-mode-only" width=64/></td>
<td colspan="2"><img src="../images/cv-cyrl-yeri-round.light.svg#gh-light-mode-only" width=64/><img src="../images/cv-cyrl-yeri-round.dark.svg#gh-dark-mode-only" width=64/></td>
<td colspan="2"><img src="../images/cv-cyrl-yeri-cursive.light.svg#gh-light-mode-only" width=64/><img src="../images/cv-cyrl-yeri-cursive.dark.svg#gh-dark-mode-only" width=64/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td colspan="2">1</td>
<td colspan="2">2</td>
<td colspan="2">3</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="2"><code>VAAG</code></td>
<td><img src="../images/cv-cyrl-yery-corner.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-yery-corner.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-yery-corner-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-yery-corner-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-yery-round.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-yery-round.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-yery-round-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-yery-round-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-yery-cursive.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-yery-cursive.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-yery-cursive-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-yery-cursive-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="4"><code>VAAH</code></td>
<td><img src="../images/cv-cyrl-capital-e-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-e-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-e-unilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-e-unilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-e-unilateral-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-e-unilateral-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-e-bilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-e-bilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-e-unilateral-inward-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-e-unilateral-inward-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-e-unilateral-bottom-inward-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-e-unilateral-bottom-inward-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-e-bilateral-inward-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-e-bilateral-inward-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-e-unilateral-mid-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-e-unilateral-mid-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-e-unilateral-bottom-mid-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-e-unilateral-bottom-mid-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-e-bilateral-mid-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-e-bilateral-mid-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-e-unilateral-inward-mid-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-e-unilateral-inward-mid-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-e-unilateral-bottom-inward-mid-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-e-unilateral-bottom-inward-mid-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-cyrl-capital-e-bilateral-inward-mid-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-e-bilateral-inward-mid-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="11"> </td>
</tr>
<tr>
<td>13</td>
<td colspan="11"> </td>
</tr>
<tr>
<td rowspan="4"><code>VAAI</code></td>
<td><img src="../images/cv-cyrl-e-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-e-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-e-unilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-e-unilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-e-unilateral-bottom-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-e-unilateral-bottom-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-e-bilateral-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-e-bilateral-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-e-unilateral-inward-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-e-unilateral-inward-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-e-unilateral-bottom-inward-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-e-unilateral-bottom-inward-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-e-bilateral-inward-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-e-bilateral-inward-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-e-unilateral-mid-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-e-unilateral-mid-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-e-unilateral-bottom-mid-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-e-unilateral-bottom-mid-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-e-bilateral-mid-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-e-bilateral-mid-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-e-unilateral-inward-mid-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-e-unilateral-inward-mid-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-e-unilateral-bottom-inward-mid-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-e-unilateral-bottom-inward-mid-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-cyrl-e-bilateral-inward-mid-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-e-bilateral-inward-mid-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="11"> </td>
</tr>
<tr>
<td>13</td>
<td colspan="11"> </td>
</tr>
<tr>
<td rowspan="4"><code>VAAJ</code></td>
<td><img src="../images/cv-cyrl-capital-ya-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ya-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ya-straight-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ya-straight-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ya-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ya-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ya-straight-open-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ya-straight-open-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ya-straight-open-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ya-straight-open-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ya-straight-open-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ya-straight-open-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ya-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ya-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ya-curly-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ya-curly-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ya-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ya-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ya-curly-open-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ya-curly-open-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ya-curly-open-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ya-curly-open-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ya-curly-open-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ya-curly-open-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-cyrl-capital-ya-standing-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ya-standing-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ya-standing-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ya-standing-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ya-standing-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ya-standing-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ya-standing-open-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ya-standing-open-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ya-standing-open-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ya-standing-open-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-capital-ya-standing-open-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-capital-ya-standing-open-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="6"><code>VAAK</code></td>
<td><img src="../images/cv-cyrl-ya-straight-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-straight-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-straight-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-straight-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-straight-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-straight-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-straight-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-straight-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-straight-tailed-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-straight-tailed-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-straight-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-straight-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-straight-open-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-straight-open-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-straight-open-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-straight-open-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-straight-open-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-straight-open-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-straight-open-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-straight-open-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-straight-open-tailed-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-straight-open-tailed-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-straight-open-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-straight-open-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-cyrl-ya-curly-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-curly-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-curly-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-curly-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-curly-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-curly-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-curly-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-curly-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-curly-tailed-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-curly-tailed-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-curly-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-curly-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-curly-open-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-curly-open-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-curly-open-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-curly-open-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-curly-open-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-curly-open-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-curly-open-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-curly-open-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-curly-open-tailed-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-curly-open-tailed-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-curly-open-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-curly-open-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td>21</td>
<td>22</td>
<td>23</td>
<td>24</td>
</tr>
<tr>
<td><img src="../images/cv-cyrl-ya-standing-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-standing-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-standing-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-standing-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-standing-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-standing-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-standing-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-standing-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-standing-tailed-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-standing-tailed-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-standing-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-standing-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-standing-open-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-standing-open-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-standing-open-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-standing-open-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-standing-open-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-standing-open-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-standing-open-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-standing-open-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-standing-open-tailed-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-standing-open-tailed-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cyrl-ya-standing-open-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cyrl-ya-standing-open-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>25</td>
<td>26</td>
<td>27</td>
<td>28</td>
<td>29</td>
<td>30</td>
<td>31</td>
<td>32</td>
<td>33</td>
<td>34</td>
<td>35</td>
<td>36</td>
</tr>
<tr>
<td rowspan="2"><code>VDAA</code></td>
<td colspan="2"><img src="../images/cv-tittle-round.light.svg#gh-light-mode-only" width=64/><img src="../images/cv-tittle-round.dark.svg#gh-dark-mode-only" width=64/></td>
<td colspan="2"><img src="../images/cv-tittle-square.light.svg#gh-light-mode-only" width=64/><img src="../images/cv-tittle-square.dark.svg#gh-dark-mode-only" width=64/></td>
<td colspan="8"> </td>
</tr>
<tr>
<td colspan="2">1</td>
<td colspan="2">2</td>
<td colspan="8"> </td>
</tr>
<tr>
<td rowspan="2"><code>VDAB</code></td>
<td colspan="3"><img src="../images/cv-diacritic-dot-round.light.svg#gh-light-mode-only" width=96/><img src="../images/cv-diacritic-dot-round.dark.svg#gh-dark-mode-only" width=96/></td>
<td colspan="3"><img src="../images/cv-diacritic-dot-square.light.svg#gh-light-mode-only" width=96/><img src="../images/cv-diacritic-dot-square.dark.svg#gh-dark-mode-only" width=96/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td colspan="3">1</td>
<td colspan="3">2</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="2"><code>VDAC</code></td>
<td colspan="6"><img src="../images/cv-punctuation-dot-round.light.svg#gh-light-mode-only" width=192/><img src="../images/cv-punctuation-dot-round.dark.svg#gh-dark-mode-only" width=192/></td>
<td colspan="6"><img src="../images/cv-punctuation-dot-square.light.svg#gh-light-mode-only" width=192/><img src="../images/cv-punctuation-dot-square.dark.svg#gh-dark-mode-only" width=192/></td>
</tr>
<tr>
<td colspan="6">1</td>
<td colspan="6">2</td>
</tr>
<tr>
<td rowspan="2"><code>VDAD</code></td>
<td colspan="2"><img src="../images/cv-braille-dot-round.light.svg#gh-light-mode-only" width=64/><img src="../images/cv-braille-dot-round.dark.svg#gh-dark-mode-only" width=64/></td>
<td colspan="2"><img src="../images/cv-braille-dot-square.light.svg#gh-light-mode-only" width=64/><img src="../images/cv-braille-dot-square.dark.svg#gh-dark-mode-only" width=64/></td>
<td colspan="8"> </td>
</tr>
<tr>
<td colspan="2">1</td>
<td colspan="2">2</td>
<td colspan="8"> </td>
</tr>
<tr>
<td rowspan="2"><code>VSAA</code></td>
<td><img src="../images/cv-tilde-high.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-tilde-high.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-tilde-low.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-tilde-low.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="10"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td colspan="10"> </td>
</tr>
<tr>
<td rowspan="2"><code>VSAB</code></td>
<td><img src="../images/cv-asterisk-penta-high.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-asterisk-penta-high.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-asterisk-penta-mid.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-asterisk-penta-mid.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-asterisk-penta-low.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-asterisk-penta-low.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-asterisk-turn-penta-high.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-asterisk-turn-penta-high.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-asterisk-turn-penta-mid.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-asterisk-turn-penta-mid.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-asterisk-turn-penta-low.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-asterisk-turn-penta-low.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-asterisk-hex-high.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-asterisk-hex-high.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-asterisk-hex-mid.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-asterisk-hex-mid.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-asterisk-hex-low.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-asterisk-hex-low.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-asterisk-turn-hex-high.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-asterisk-turn-hex-high.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-asterisk-turn-hex-mid.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-asterisk-turn-hex-mid.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-asterisk-turn-hex-low.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-asterisk-turn-hex-low.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td rowspan="2"><code>VSAC</code></td>
<td><img src="../images/cv-underscore-above-baseline.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-underscore-above-baseline.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-underscore-high.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-underscore-high.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-underscore-low.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-underscore-low.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="2"><code>VSAD</code></td>
<td><img src="../images/cv-caret-high.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-caret-high.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-caret-medium.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-caret-medium.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-caret-low.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-caret-low.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="2"><code>VSAE</code></td>
<td><img src="../images/cv-ascii-grave-straight.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-ascii-grave-straight.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-ascii-grave-raised-inverse-comma.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-ascii-grave-raised-inverse-comma.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-ascii-grave-raised-turn-comma.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-ascii-grave-raised-turn-comma.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="2"><code>VSAF</code></td>
<td><img src="../images/cv-ascii-single-quote-straight.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-ascii-single-quote-straight.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-ascii-single-quote-raised-comma.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-ascii-single-quote-raised-comma.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="10"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td colspan="10"> </td>
</tr>
<tr>
<td rowspan="2"><code>VSAG</code></td>
<td colspan="2"><img src="../images/cv-paren-normal.light.svg#gh-light-mode-only" width=64/><img src="../images/cv-paren-normal.dark.svg#gh-dark-mode-only" width=64/></td>
<td colspan="2"><img src="../images/cv-paren-large-contour.light.svg#gh-light-mode-only" width=64/><img src="../images/cv-paren-large-contour.dark.svg#gh-dark-mode-only" width=64/></td>
<td colspan="2"><img src="../images/cv-paren-flat-arc.light.svg#gh-light-mode-only" width=64/><img src="../images/cv-paren-flat-arc.dark.svg#gh-dark-mode-only" width=64/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td colspan="2">1</td>
<td colspan="2">2</td>
<td colspan="2">3</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="2"><code>VSAH</code></td>
<td colspan="2"><img src="../images/cv-brace-straight.light.svg#gh-light-mode-only" width=64/><img src="../images/cv-brace-straight.dark.svg#gh-dark-mode-only" width=64/></td>
<td colspan="2"><img src="../images/cv-brace-curly.light.svg#gh-light-mode-only" width=64/><img src="../images/cv-brace-curly.dark.svg#gh-dark-mode-only" width=64/></td>
<td colspan="2"><img src="../images/cv-brace-curly-flat-boundary.light.svg#gh-light-mode-only" width=64/><img src="../images/cv-brace-curly-flat-boundary.dark.svg#gh-dark-mode-only" width=64/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td colspan="2">1</td>
<td colspan="2">2</td>
<td colspan="2">3</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="2"><code>VSAI</code></td>
<td colspan="2"><img src="../images/cv-guillemet-straight.light.svg#gh-light-mode-only" width=64/><img src="../images/cv-guillemet-straight.dark.svg#gh-dark-mode-only" width=64/></td>
<td colspan="2"><img src="../images/cv-guillemet-curly.light.svg#gh-light-mode-only" width=64/><img src="../images/cv-guillemet-curly.dark.svg#gh-dark-mode-only" width=64/></td>
<td colspan="8"> </td>
</tr>
<tr>
<td colspan="2">1</td>
<td colspan="2">2</td>
<td colspan="8"> </td>
</tr>
<tr>
<td rowspan="2"><code>VSAJ</code></td>
<td><img src="../images/cv-number-sign-upright.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-number-sign-upright.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-number-sign-slanted.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-number-sign-slanted.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-number-sign-upright-open.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-number-sign-upright-open.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-number-sign-slanted-open.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-number-sign-slanted-open.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-number-sign-upright-tall.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-number-sign-upright-tall.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-number-sign-slanted-tall.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-number-sign-slanted-tall.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-number-sign-upright-open-tall.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-number-sign-upright-open-tall.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-number-sign-slanted-open-tall.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-number-sign-slanted-open-tall.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="4"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td colspan="4"> </td>
</tr>
<tr>
<td rowspan="2"><code>VSAK</code></td>
<td><img src="../images/cv-ampersand-closed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-ampersand-closed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-ampersand-upper-open.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-ampersand-upper-open.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-ampersand-lower-open.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-ampersand-lower-open.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-ampersand-flat-top.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-ampersand-flat-top.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-ampersand-et-toothed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-ampersand-et-toothed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-ampersand-et-toothless-corner.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-ampersand-et-toothless-corner.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-ampersand-et-toothless-rounded.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-ampersand-et-toothless-rounded.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-ampersand-et-tailed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-ampersand-et-tailed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="4"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td colspan="4"> </td>
</tr>
<tr>
<td rowspan="2"><code>VSAL</code></td>
<td><img src="../images/cv-at-threefold.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-at-threefold.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-at-threefold-tall.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-at-threefold-tall.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-at-threefold-solid-inner.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-at-threefold-solid-inner.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-at-threefold-solid-inner-tall.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-at-threefold-solid-inner-tall.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-at-fourfold.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-at-fourfold.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-at-fourfold-tall.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-at-fourfold-tall.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-at-fourfold-solid-inner.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-at-fourfold-solid-inner.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-at-fourfold-solid-inner-tall.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-at-fourfold-solid-inner-tall.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-at-compact.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-at-compact.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="3"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td colspan="3"> </td>
</tr>
<tr>
<td rowspan="2"><code>VSAM</code></td>
<td><img src="../images/cv-dollar-open.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-dollar-open.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-dollar-slanted-open.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-dollar-slanted-open.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-dollar-through.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-dollar-through.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-dollar-slanted-through.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-dollar-slanted-through.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-dollar-interrupted.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-dollar-interrupted.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-dollar-slanted-interrupted.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-dollar-slanted-interrupted.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-dollar-open-cap.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-dollar-open-cap.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-dollar-slanted-open-cap.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-dollar-slanted-open-cap.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-dollar-through-cap.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-dollar-through-cap.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-dollar-slanted-through-cap.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-dollar-slanted-through-cap.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-dollar-interrupted-cap.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-dollar-interrupted-cap.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-dollar-slanted-interrupted-cap.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-dollar-slanted-interrupted-cap.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td rowspan="2"><code>VSAN</code></td>
<td><img src="../images/cv-cent-open.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cent-open.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cent-slanted-open.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cent-slanted-open.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cent-through.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cent-through.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cent-slanted-through.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cent-slanted-through.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cent-bar-interrupted.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cent-bar-interrupted.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cent-slanted-bar-interrupted.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cent-slanted-bar-interrupted.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cent-open-cap.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cent-open-cap.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cent-slanted-open-cap.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cent-slanted-open-cap.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cent-through-cap.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cent-through-cap.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cent-slanted-through-cap.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cent-slanted-through-cap.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cent-bar-interrupted-cap.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cent-bar-interrupted-cap.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-cent-slanted-bar-interrupted-cap.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-cent-slanted-bar-interrupted-cap.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td rowspan="2"><code>VSAO</code></td>
<td><img src="../images/cv-percent-dots.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-percent-dots.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-percent-rings-segmented-slash.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-percent-rings-segmented-slash.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-percent-rings-continuous-slash.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-percent-rings-continuous-slash.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-percent-rings-continuous-slash-also-connected.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-percent-rings-continuous-slash-also-connected.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="8"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td colspan="8"> </td>
</tr>
<tr>
<td rowspan="2"><code>VSAP</code></td>
<td colspan="4"><img src="../images/cv-bar-natural-slope.light.svg#gh-light-mode-only" width=128/><img src="../images/cv-bar-natural-slope.dark.svg#gh-dark-mode-only" width=128/></td>
<td colspan="4"><img src="../images/cv-bar-force-upright.light.svg#gh-light-mode-only" width=128/><img src="../images/cv-bar-force-upright.dark.svg#gh-dark-mode-only" width=128/></td>
<td colspan="4"> </td>
</tr>
<tr>
<td colspan="4">1</td>
<td colspan="4">2</td>
<td colspan="4"> </td>
</tr>
<tr>
<td rowspan="2"><code>VSAQ</code></td>
<td><img src="../images/cv-question-smooth.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-question-smooth.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-question-corner.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-question-corner.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-question-corner-flat-hooked.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-question-corner-flat-hooked.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="2"><code>VSAR</code></td>
<td><img src="../images/cv-pilcrow-high.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-pilcrow-high.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-pilcrow-low.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-pilcrow-low.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-pilcrow-curved.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-pilcrow-curved.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="9"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td colspan="9"> </td>
</tr>
<tr>
<td rowspan="4"><code>VSAS</code></td>
<td><img src="../images/cv-micro-sign-toothed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-micro-sign-toothed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-micro-sign-toothed-bottom-right-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-micro-sign-toothed-bottom-right-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-micro-sign-toothed-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-micro-sign-toothed-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-micro-sign-toothed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-micro-sign-toothed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-micro-sign-tailed-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-micro-sign-tailed-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-micro-sign-tailed-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-micro-sign-tailed-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-micro-sign-tailed-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-micro-sign-tailed-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-micro-sign-toothless-corner-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-micro-sign-toothless-corner-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-micro-sign-toothless-corner-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-micro-sign-toothless-corner-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-micro-sign-toothless-corner-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-micro-sign-toothless-corner-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-micro-sign-toothless-rounded-serifless.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-micro-sign-toothless-rounded-serifless.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-micro-sign-toothless-rounded-motion-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-micro-sign-toothless-rounded-motion-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
<td>11</td>
<td>12</td>
</tr>
<tr>
<td><img src="../images/cv-micro-sign-toothless-rounded-serifed.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-micro-sign-toothless-rounded-serifed.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="11"> </td>
</tr>
<tr>
<td>13</td>
<td colspan="11"> </td>
</tr>
<tr>
<td rowspan="2"><code>VSAT</code></td>
<td colspan="2"><img src="../images/cv-decorative-angle-brackets-tall.light.svg#gh-light-mode-only" width=64/><img src="../images/cv-decorative-angle-brackets-tall.dark.svg#gh-dark-mode-only" width=64/></td>
<td colspan="2"><img src="../images/cv-decorative-angle-brackets-middle.light.svg#gh-light-mode-only" width=64/><img src="../images/cv-decorative-angle-brackets-middle.dark.svg#gh-dark-mode-only" width=64/></td>
<td colspan="2"><img src="../images/cv-decorative-angle-brackets-short.light.svg#gh-light-mode-only" width=64/><img src="../images/cv-decorative-angle-brackets-short.dark.svg#gh-dark-mode-only" width=64/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td colspan="2">1</td>
<td colspan="2">2</td>
<td colspan="2">3</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="2"><code>VLAA</code></td>
<td colspan="2"><img src="../images/cv-lig-ltgteq-flat.light.svg#gh-light-mode-only" width=64/><img src="../images/cv-lig-ltgteq-flat.dark.svg#gh-dark-mode-only" width=64/></td>
<td colspan="2"><img src="../images/cv-lig-ltgteq-slanted.light.svg#gh-light-mode-only" width=64/><img src="../images/cv-lig-ltgteq-slanted.dark.svg#gh-dark-mode-only" width=64/></td>
<td colspan="8"> </td>
</tr>
<tr>
<td colspan="2">1</td>
<td colspan="2">2</td>
<td colspan="8"> </td>
</tr>
<tr>
<td rowspan="2"><code>VLAB</code></td>
<td><img src="../images/cv-lig-neq-vertical.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lig-neq-vertical.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lig-neq-slightly-slanted.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lig-neq-slightly-slanted.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lig-neq-more-slanted.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lig-neq-more-slanted.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lig-neq-vertical-dotted.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lig-neq-vertical-dotted.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lig-neq-slightly-slanted-dotted.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lig-neq-slightly-slanted-dotted.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lig-neq-more-slanted-dotted.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lig-neq-more-slanted-dotted.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="6"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td colspan="6"> </td>
</tr>
<tr>
<td rowspan="2"><code>VLAC</code></td>
<td><img src="../images/cv-lig-equal-chain-with-notch.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lig-equal-chain-with-notch.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lig-equal-chain-without-notch.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lig-equal-chain-without-notch.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="10"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td colspan="10"> </td>
</tr>
<tr>
<td rowspan="2"><code>VLAD</code></td>
<td><img src="../images/cv-lig-hyphen-chain-with-notch.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lig-hyphen-chain-with-notch.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lig-hyphen-chain-without-notch.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lig-hyphen-chain-without-notch.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="10"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td colspan="10"> </td>
</tr>
<tr>
<td rowspan="2"><code>VLAE</code></td>
<td><img src="../images/cv-lig-plus-chain-with-notch.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lig-plus-chain-with-notch.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lig-plus-chain-without-notch.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lig-plus-chain-without-notch.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="10"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td colspan="10"> </td>
</tr>
<tr>
<td rowspan="2"><code>VLAF</code></td>
<td><img src="../images/cv-lig-double-arrow-bar-with-notch.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lig-double-arrow-bar-with-notch.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lig-double-arrow-bar-without-notch.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lig-double-arrow-bar-without-notch.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="10"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td colspan="10"> </td>
</tr>
<tr>
<td rowspan="2"><code>VLAG</code></td>
<td><img src="../images/cv-lig-single-arrow-bar-with-notch.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lig-single-arrow-bar-with-notch.dark.svg#gh-dark-mode-only" width=32/></td>
<td><img src="../images/cv-lig-single-arrow-bar-without-notch.light.svg#gh-light-mode-only" width=32/><img src="../images/cv-lig-single-arrow-bar-without-notch.dark.svg#gh-dark-mode-only" width=32/></td>
<td colspan="10"> </td>
</tr>
<tr>
<td>1</td>
<td>2</td>
<td colspan="10"> </td>
</tr>
</table>

<!-- END Section-OT-Character-Variants -->
