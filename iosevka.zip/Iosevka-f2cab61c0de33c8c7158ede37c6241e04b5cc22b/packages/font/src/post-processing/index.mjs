import { postProcessingFeatureParams } from "./feature-params.mjs";

export function postProcessFont(para, font) {
	postProcessingFeatureParams(para, font);
}
